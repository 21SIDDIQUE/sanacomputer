module.exports = {
  globals: {
    loadGlobals: "readonly",
    isNode: "readonly",
    comparePdf: "readonly"
  }
};
